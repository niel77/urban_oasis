"use client"

import { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import type { PropertyType } from "../types/property"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { propertyService } from "../services/property-service"
import { Camera, Upload, X, File, ImagePlusIcon as Image360, QrCode } from "lucide-react"

interface PropertyMediaProps {
  property: PropertyType
  setProperty: (property: PropertyType) => void
}

export function PropertyMedia({ property, setProperty }: PropertyMediaProps) {
  const [isUploading, setIsUploading] = useState(false)

  // Ensure media object and its properties are initialized
  const media = property.media || {}
  const images = media.images || []
  const floorPlans = media.floorPlans || []
  const threeSixtyMedia = media.threeSixtyMedia || []
  const qrCode = media.qrCode || ""

  const onDrop = useCallback(
    async (acceptedFiles: File[], mediaType: "images" | "floorPlans" | "threeSixtyMedia") => {
      setIsUploading(true)
      try {
        if (property.id) {
          let urls: string[] = []
          if (mediaType === "images") {
            urls = await propertyService.uploadImages(property.id, acceptedFiles)
          } else if (mediaType === "floorPlans") {
            urls = await propertyService.uploadFloorPlans(property.id, acceptedFiles)
          } else if (mediaType === "threeSixtyMedia") {
            urls = await propertyService.uploadThreeSixtyMedia(property.id, acceptedFiles)
          }
          setProperty({
            ...property,
            media: {
              ...property.media,
              [mediaType]: [...(property.media?.[mediaType] || []), ...urls],
            },
          })
        }
      } catch (error) {
        console.error(`Error uploading ${mediaType}:`, error)
        alert(`Failed to upload ${mediaType}. Please try again.`)
      } finally {
        setIsUploading(false)
      }
    },
    [property, setProperty],
  )

  const { getRootProps: getImageProps, getInputProps: getImageInputProps } = useDropzone({
    onDrop: (files) => onDrop(files, "images"),
    accept: {
      "image/*": [".jpeg", ".jpg", ".png"],
    },
  })

  const { getRootProps: getFloorPlanProps, getInputProps: getFloorPlanInputProps } = useDropzone({
    onDrop: (files) => onDrop(files, "floorPlans"),
    accept: {
      "image/*": [".jpeg", ".jpg", ".png"],
      "application/pdf": [".pdf"],
    },
  })

  const { getRootProps: getThreeSixtyProps, getInputProps: getThreeSixtyInputProps } = useDropzone({
    onDrop: (files) => onDrop(files, "threeSixtyMedia"),
    accept: {
      "image/*": [".jpeg", ".jpg", ".png"],
      "video/*": [".mp4", ".webm"],
    },
  })

  const handleQRCodeUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file && property.id) {
      setIsUploading(true)
      try {
        const url = await propertyService.uploadQRCode(property.id, file)
        setProperty({
          ...property,
          media: {
            ...property.media,
            qrCode: url,
          },
        })
      } catch (error) {
        console.error("Error uploading QR code:", error)
        alert("Failed to upload QR code. Please try again.")
      } finally {
        setIsUploading(false)
      }
    }
  }

  const removeMedia = (mediaType: "images" | "floorPlans" | "threeSixtyMedia", index: number) => {
    const newMedia = [...(property.media?.[mediaType] || [])]
    newMedia.splice(index, 1)
    setProperty({
      ...property,
      media: {
        ...property.media,
        [mediaType]: newMedia,
      },
    })
  }

  const removeQRCode = () => {
    setProperty({
      ...property,
      media: {
        ...property.media,
        qrCode: "",
      },
    })
  }

  return (
    <div className="space-y-8 p-6">
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Property Images</h3>
        <div {...getImageProps()} className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer">
          <input {...getImageInputProps()} />
          <Camera className="mx-auto h-12 w-12 text-gray-400" />
          <p className="mt-2">Drag 'n' drop some images here, or click to select files</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-4">
          {images.map((image, index) => (
            <Card key={index} className="relative aspect-square">
              <img
                src={image || "/placeholder.svg"}
                alt={`Property image ${index + 1}`}
                className="object-cover w-full h-full rounded-lg"
              />
              <Button
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => removeMedia("images", index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </Card>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Floor Plans</h3>
        <div {...getFloorPlanProps()} className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer">
          <input {...getFloorPlanInputProps()} />
          <File className="mx-auto h-12 w-12 text-gray-400" />
          <p className="mt-2">Drag 'n' drop floor plans here, or click to select files</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-4">
          {floorPlans.map((plan, index) => (
            <Card key={index} className="relative p-4">
              <a href={plan} target="_blank" rel="noopener noreferrer" className="block text-center">
                <File className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm">Floor Plan {index + 1}</p>
              </a>
              <Button
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => removeMedia("floorPlans", index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </Card>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold">360° Media</h3>
        <div {...getThreeSixtyProps()} className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer">
          <input {...getThreeSixtyInputProps()} />
          <Image360 className="mx-auto h-12 w-12 text-gray-400" />
          <p className="mt-2">Drag 'n' drop 360° images or videos here, or click to select files</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-4">
          {threeSixtyMedia.map((media, index) => (
            <Card key={index} className="relative aspect-square">
              {media.endsWith(".mp4") || media.endsWith(".webm") ? (
                <video src={media} className="w-full h-full object-cover rounded-lg" controls />
              ) : (
                <img
                  src={media || "/placeholder.svg"}
                  alt={`360° media ${index + 1}`}
                  className="object-cover w-full h-full rounded-lg"
                />
              )}
              <Button
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => removeMedia("threeSixtyMedia", index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </Card>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold">QR Code</h3>
        <div className="flex items-center space-x-4">
          <Input type="file" onChange={handleQRCodeUpload} accept="image/*" disabled={isUploading || !!qrCode} />
          <Button onClick={() => document.getElementById("qrCodeUpload")?.click()} disabled={isUploading || !!qrCode}>
            <Upload className="mr-2 h-4 w-4" /> Upload QR Code
          </Button>
        </div>
        {qrCode && (
          <Card className="relative inline-block">
            <img src={qrCode || "/placeholder.svg"} alt="Property QR Code" className="w-40 h-40 object-contain" />
            <Button variant="destructive" size="icon" className="absolute top-2 right-2" onClick={removeQRCode}>
              <X className="h-4 w-4" />
            </Button>
          </Card>
        )}
      </div>

      {isUploading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-4 rounded-lg">
            <p className="text-lg font-semibold">Uploading...</p>
          </div>
        </div>
      )}
    </div>
  )
}

