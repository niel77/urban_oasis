"use client"

import { PropertyForm } from "../components/property-form"

export default function SyntheticV0PageForDeployment() {
  return <PropertyForm />
}