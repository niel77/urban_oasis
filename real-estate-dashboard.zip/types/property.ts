export interface PropertyType {
  id?: string
  type: "RESIDENTIAL" | "COMMERCIAL"
  listingType: "RENT" | "SALE"
  specifications: {
    titleDeed: string
    propertyType: string
    size: number
    bedrooms: number
    bathrooms: number
    parkingSpaces: number
    furnishingType: string
    builtUpArea: number
    totalPlotSize: number
    layoutType: string
  }
  pricing: {
    type: "YEAR" | "MONTH" | "WEEK" | "DAY"
    amount: number
    currency: "AED"
  }
  location: {
    address: string
    unitNo: string
    coordinates: {
      latitude: number
      longitude: number
    }
  }
  media: {
    images: string[]
    floorPlans: string[]
    threeSixtyMedia: string[]
    qrCode: string
  }
  management: {
    reference: string
    owner: string
    availability: "AVAILABLE" | "UNDER_OFFER" | "RESERVED" | "RENTED"
    availableFrom: Date
  }
  propertyPermit: {
    type: "RERA" | "DTCM"
    number: string
  }
  status: "DRAFT" | "PUBLISHED"
  createdAt: Date
  updatedAt: Date
  createdBy: string
}

