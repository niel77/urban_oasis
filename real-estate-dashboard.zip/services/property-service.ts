import type { PropertyType } from "../types/property"

class PropertyService {
  private baseUrl = "/api/properties"

  async createProperty(property: PropertyType): Promise<PropertyType> {
    const response = await fetch(this.baseUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(property),
    })
    if (!response.ok) {
      throw new Error("Failed to create property")
    }
    return response.json()
  }

  async uploadImages(propertyId: string, files: File[]): Promise<string[]> {
    return this.uploadFiles(propertyId, files, "images")
  }

  async uploadFloorPlans(propertyId: string, files: File[]): Promise<string[]> {
    return this.uploadFiles(propertyId, files, "floor-plans")
  }

  async uploadThreeSixtyMedia(propertyId: string, files: File[]): Promise<string[]> {
    return this.uploadFiles(propertyId, files, "360-media")
  }

  async uploadQRCode(propertyId: string, file: File): Promise<string> {
    const formData = new FormData()
    formData.append("file", file)

    const response = await fetch(`${this.baseUrl}/${propertyId}/qr-code`, {
      method: "POST",
      body: formData,
    })
    if (!response.ok) {
      throw new Error("Failed to upload QR code")
    }
    const result = await response.json()
    return result.url
  }

  private async uploadFiles(propertyId: string, files: File[], endpoint: string): Promise<string[]> {
    const formData = new FormData()
    files.forEach((file) => formData.append("files", file))

    const response = await fetch(`${this.baseUrl}/${propertyId}/${endpoint}`, {
      method: "POST",
      body: formData,
    })
    if (!response.ok) {
      throw new Error(`Failed to upload ${endpoint}`)
    }
    return response.json()
  }

  async getDraftProperties(): Promise<PropertyType[]> {
    const response = await fetch(`${this.baseUrl}?status=DRAFT`)
    if (!response.ok) {
      throw new Error("Failed to fetch draft properties")
    }
    return response.json()
  }

  async publishProperty(propertyId: string): Promise<PropertyType> {
    const response = await fetch(`${this.baseUrl}/${propertyId}/publish`, {
      method: "PUT",
    })
    if (!response.ok) {
      throw new Error("Failed to publish property")
    }
    return response.json()
  }
}

// Export a singleton instance instead of the class
export const propertyService = new PropertyService()

