import React, { useState, useEffect } from 'react';
import { Phone, Mail, MessageCircle, MapPin, Calendar, Home, DollarSign, Maximize, Image as Image360, Building2, Award, Check } from 'lucide-react';
import MortgageCalculator from './components/MortgageCalculator';
import SignupForm from './components/SignupForm';
import PropertyGallery from './components/PropertyGallery';
import FloorPlan from './components/FloorPlan';

function App() {
  const [showSignup, setShowSignup] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const amenities = [
    'Private Beach Access',
    'Swimming Pool',
    'Fitness Center',
    '24/7 Security',
    'Parking',
    'Kids Play Area',
    'Retail Outlets',
    'Marina Access'
  ];

  const paymentPlan = [
    { milestone: 'Booking', percentage: '10%' },
    { milestone: 'Construction Progress (30%)', percentage: '20%' },
    { milestone: 'Construction Progress (60%)', percentage: '30%' },
    { milestone: 'Completion', percentage: '40%' }
  ];

  const highlights = [
    { icon: Award, title: 'Award Winning', description: 'Internationally recognized design excellence' },
    { icon: Building2, title: 'Prime Location', description: 'Heart of Wasl1, Dubai' },
    { icon: Home, title: 'Luxury Living', description: 'Premium finishes and amenities' }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white shadow-md' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className={`text-2xl font-bold ${scrolled ? 'text-blue-600' : 'text-white'}`}>Avenue Park Towers</h1>
          <button 
            onClick={() => setShowSignup(true)}
            className={`px-6 py-2 rounded-lg transition-all duration-300 ${
              scrolled 
                ? 'bg-blue-600 text-white hover:bg-blue-700' 
                : 'bg-white text-blue-600 hover:bg-blue-50'
            }`}
          >
            Register Interest
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative h-screen">
        <img 
          src="https://images.unsplash.com/photo-1609347744403-2306e8a9ae27?auto=format&fit=crop&q=80"
          alt="Avenue Park Towers Wasl1"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-black/30 flex items-center justify-center">
          <div className="text-center text-white px-4 max-w-4xl">
            <h1 className="text-7xl font-bold mb-4 animate-fadeInUp">
              Avenue Park Towers
            </h1>
            <p className="text-3xl mb-3 font-light animate-fadeInUp animate-delay-100">
              Wasl1, Dubai
            </p>
            <p className="text-xl mb-8 tracking-wide animate-fadeInUp animate-delay-200">
              Luxury Living Starting from AED 3 Million
            </p>
            <button 
              onClick={() => setShowSignup(true)}
              className="glass-effect px-10 py-4 rounded-lg hover:bg-white/30 transition-all duration-300 transform hover:scale-105 animate-fadeInUp animate-delay-300 text-lg font-medium"
            >
              Register Interest
            </button>
          </div>
        </div>
      </div>

      {/* Highlights Section */}
      <section className="py-16 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            {highlights.map((highlight, index) => (
              <div key={index} className="hover-card bg-white p-8 rounded-xl shadow-sm">
                <highlight.icon className="text-blue-600 mb-4" size={32} />
                <h3 className="text-xl font-semibold mb-2">{highlight.title}</h3>
                <p className="text-gray-600">{highlight.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Buttons */}
      <div className="fixed right-6 top-1/2 transform -translate-y-1/2 space-y-4 z-40">
        <a href="tel:+971500000000" className="flex items-center justify-center w-14 h-14 bg-green-500 rounded-full hover:bg-green-600 transition-all duration-300 transform hover:scale-110 shadow-lg animate-float">
          <Phone className="text-white" size={24} />
        </a>
        <a href="mailto:info@avenueparktowers.com" className="flex items-center justify-center w-14 h-14 bg-blue-500 rounded-full hover:bg-blue-600 transition-all duration-300 transform hover:scale-110 shadow-lg animate-float animate-delay-100">
          <Mail className="text-white" size={24} />
        </a>
        <a href="https://wa.me/971500000000" className="flex items-center justify-center w-14 h-14 bg-green-600 rounded-full hover:bg-green-700 transition-all duration-300 transform hover:scale-110 shadow-lg animate-float animate-delay-200">
          <MessageCircle className="text-white" size={24} />
        </a>
      </div>

      {/* Property Details */}
      <section className="py-20 px-4 max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold mb-4 text-center gradient-text">Property Overview</h2>
        <p className="text-gray-600 text-center mb-12 max-w-2xl mx-auto">Experience luxury living redefined at Dubai's most prestigious address</p>
        <div className="grid md:grid-cols-2 gap-12">
          <div className="animate-slideInLeft">
            <p className="text-gray-700 leading-relaxed text-lg">
              Welcome to Avenue Park Towers at Wasl1, where luxury meets urban sophistication. This exclusive development 
              offers meticulously crafted apartments in the heart of Dubai. Nestled in the prestigious Wasl1 district, 
              these residences are a testament to contemporary design and refined living.
            </p>
            <p className="mt-4 text-gray-700 leading-relaxed text-lg">
              Each residence is thoughtfully designed to provide an unparalleled living experience, combining premium 
              finishes with panoramic views of Dubai's iconic skyline.
            </p>
            <div className="mt-12">
              <h3 className="text-2xl font-semibold mb-6">Key Features:</h3>
              <ul className="grid grid-cols-2 gap-6">
                {amenities.map((amenity, index) => (
                  <li key={index} className="flex items-center gap-3 text-lg group">
                    <Check className="text-blue-600 transform group-hover:scale-110 transition-transform" />
                    {amenity}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div className="space-y-6 animate-slideInRight">
            <div className="hover-card bg-gray-50 p-8 rounded-xl">
              <h3 className="text-2xl font-semibold mb-4">Price Range</h3>
              <p className="text-4xl text-blue-600 font-bold">AED 3M - 8M</p>
            </div>
            <div className="hover-card bg-gray-50 p-8 rounded-xl">
              <h3 className="text-2xl font-semibold mb-4">Location</h3>
              <div className="flex items-center gap-3 text-lg">
                <MapPin className="text-blue-600" size={24} />
                <span>Wasl1, Dubai, UAE</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Plan */}
      <section className="bg-gray-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center">Payment Plan</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {paymentPlan.map((plan, index) => (
              <div key={index} className="bg-white p-8 rounded-xl shadow-sm transform hover:scale-105 transition-transform duration-300">
                <h3 className="text-xl font-semibold mb-3">{plan.milestone}</h3>
                <p className="text-4xl text-blue-600 font-bold">{plan.percentage}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mortgage Calculator */}
      <section className="py-20 px-4 max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">Mortgage Calculator</h2>
        <MortgageCalculator />
      </section>

      {/* Gallery */}
      <section className="py-20 px-4 max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">Property Gallery</h2>
        <PropertyGallery />
      </section>

      {/* Floor Plans */}
      <section className="bg-gray-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center">Floor Plans</h2>
          <FloorPlan />
        </div>
      </section>

      {/* Map */}
      <section className="py-20 px-4 max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">Location</h2>
        <div className="h-[400px] bg-gray-100 rounded-xl overflow-hidden shadow-sm">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3610.174553823854!2d55.2667!3d25.2048!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjXCsDEyJzE3LjMiTiA1NcKwMTYnMDAuMiJF!5e0!3m2!1sen!2sae!4v1625641234567!5m2!1sen!2sae"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="rounded-xl"
          ></iframe>
        </div>
      </section>

      {showSignup && (
        <SignupForm onClose={() => setShowSignup(false)} />
      )}
    </div>
  );
}

export default App;