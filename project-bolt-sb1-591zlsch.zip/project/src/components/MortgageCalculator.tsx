import React, { useState, useEffect } from 'react';

const MortgageCalculator = () => {
  const [price, setPrice] = useState(3000000);
  const [downPayment, setDownPayment] = useState(20);
  const [years, setYears] = useState(25);
  const [interestRate, setInterestRate] = useState(2.99);
  const [monthlyPayment, setMonthlyPayment] = useState(0);

  useEffect(() => {
    const calculateMortgage = () => {
      const principal = price * (1 - downPayment / 100);
      const monthlyRate = interestRate / 100 / 12;
      const numberOfPayments = years * 12;
      
      const monthly = principal * 
        (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / 
        (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
      
      setMonthlyPayment(monthly);
    };

    calculateMortgage();
  }, [price, downPayment, years, interestRate]);

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Property Price (AED)
            </label>
            <input
              type="range"
              min="3000000"
              max="8000000"
              step="100000"
              value={price}
              onChange={(e) => setPrice(Number(e.target.value))}
              className="w-full"
            />
            <div className="text-right text-blue-600 font-semibold">
              {price.toLocaleString()} AED
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Down Payment (%)
            </label>
            <input
              type="range"
              min="20"
              max="80"
              value={downPayment}
              onChange={(e) => setDownPayment(Number(e.target.value))}
              className="w-full"
            />
            <div className="text-right text-blue-600 font-semibold">
              {downPayment}% ({(price * downPayment / 100).toLocaleString()} AED)
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Loan Term (Years)
            </label>
            <input
              type="range"
              min="5"
              max="25"
              value={years}
              onChange={(e) => setYears(Number(e.target.value))}
              className="w-full"
            />
            <div className="text-right text-blue-600 font-semibold">
              {years} Years
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Interest Rate (%)
            </label>
            <input
              type="range"
              min="1"
              max="5"
              step="0.01"
              value={interestRate}
              onChange={(e) => setInterestRate(Number(e.target.value))}
              className="w-full"
            />
            <div className="text-right text-blue-600 font-semibold">
              {interestRate}%
            </div>
          </div>
        </div>

        <div className="bg-gray-50 p-6 rounded-lg">
          <h3 className="text-xl font-semibold mb-6">Monthly Payment</h3>
          <div className="text-4xl font-bold text-blue-600">
            {Math.round(monthlyPayment).toLocaleString()} AED
          </div>
          <div className="mt-6 space-y-4">
            <div className="flex justify-between">
              <span className="text-gray-600">Loan Amount:</span>
              <span className="font-semibold">
                {Math.round(price * (1 - downPayment / 100)).toLocaleString()} AED
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Total Interest:</span>
              <span className="font-semibold">
                {Math.round(monthlyPayment * years * 12 - price * (1 - downPayment / 100)).toLocaleString()} AED
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Total Payment:</span>
              <span className="font-semibold">
                {Math.round(monthlyPayment * years * 12).toLocaleString()} AED
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MortgageCalculator;