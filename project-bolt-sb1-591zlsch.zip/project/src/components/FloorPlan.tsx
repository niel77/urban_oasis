import React from 'react';

const FloorPlan = () => {
  const plans = [
    {
      type: "1 Bedroom",
      size: "800 sq.ft",
      price: "3,000,000",
      image: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80"
    },
    {
      type: "2 Bedroom",
      size: "1,200 sq.ft",
      price: "4,500,000",
      image: "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&q=80"
    },
    {
      type: "3 Bedroom",
      size: "1,800 sq.ft",
      price: "6,500,000",
      image: "https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&q=80"
    }
  ];

  return (
    <div className="grid md:grid-cols-3 gap-8">
      {plans.map((plan, index) => (
        <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
          <img
            src={plan.image}
            alt={`${plan.type} Floor Plan`}
            className="w-full h-48 object-cover rounded-lg mb-4"
          />
          <h3 className="text-xl font-semibold mb-2">{plan.type}</h3>
          <div className="space-y-2 text-gray-600">
            <p>Size: {plan.size}</p>
            <p>Starting Price: AED {plan.price}</p>
          </div>
          <button className="mt-4 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition">
            Download Floor Plan
          </button>
        </div>
      ))}
    </div>
  );
};

export default FloorPlan;