"use client"

import { useState } from "react"
import type { PropertyType } from "../types/property"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { propertyService } from "../services/property-service"

interface PropertyLocationProps {
  property: PropertyType
  setProperty: (property: PropertyType) => void
}

export function PropertyLocation({ property, setProperty }: PropertyLocationProps) {
  const [isSaving, setIsSaving] = useState(false)
  const [mapCenter, setMapCenter] = useState({
    lat: property.location.coordinates.latitude,
    lng: property.location.coordinates.longitude,
  })

  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProperty({
      ...property,
      location: {
        ...property.location,
        address: e.target.value,
      },
    })
  }

  const handleUnitNoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProperty({
      ...property,
      location: {
        ...property.location,
        unitNo: e.target.value,
      },
    })
  }

  const saveDraft = async () => {
    setIsSaving(true)
    try {
      const savedProperty = await propertyService.createProperty({
        ...property,
        status: "DRAFT",
      })
      setProperty(savedProperty)
      alert("Property saved as draft successfully!")
    } catch (error) {
      console.error("Error saving draft:", error)
      alert("Failed to save draft. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-6 p-6">
      <div className="grid gap-4">
        <div className="space-y-2">
          <Label htmlFor="address">Property Address</Label>
          <Input
            id="address"
            value={property.location.address}
            onChange={handleAddressChange}
            placeholder="Enter property address"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="unitNo">Unit No</Label>
          <Input
            id="unitNo"
            value={property.location.unitNo}
            onChange={handleUnitNoChange}
            placeholder="Enter unit number"
          />
        </div>
      </div>
      <div className="aspect-video bg-muted rounded-md flex items-center justify-center">
        <p className="text-muted-foreground">Map placeholder</p>
      </div>
      <p className="text-sm text-muted-foreground">
        To ensure your quality score is not impacted, type the exact location with details about the community and
        project.
      </p>
      <Button className="w-full" onClick={saveDraft} disabled={isSaving}>
        {isSaving ? "Saving..." : "Save as Draft"}
      </Button>
    </div>
  )
}

