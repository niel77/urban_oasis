"use client"

import { useState, useEffect } from "react"
import type { PropertyType } from "../types/property"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { propertyService } from "../services/property-service"

interface PropertyPublishingProps {
  property: PropertyType
  setProperty: (property: PropertyType) => void
}

export function PropertyPublishing({ property, setProperty }: PropertyPublishingProps) {
  const [draftProperties, setDraftProperties] = useState<PropertyType[]>([])
  const [isPublishing, setIsPublishing] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchDraftProperties()
  }, [])

  const fetchDraftProperties = async () => {
    setIsLoading(true)
    try {
      const drafts = await propertyService.getDraftProperties()
      setDraftProperties(drafts)
    } catch (error) {
      console.error("Error fetching draft properties:", error)
      alert("Failed to fetch draft properties. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleStatusChange = (checked: boolean) => {
    setProperty({
      ...property,
      status: checked ? "PUBLISHED" : "DRAFT",
    })
  }

  const publishProperty = async (propertyId: string) => {
    setIsPublishing(true)
    try {
      const publishedProperty = await propertyService.publishProperty(propertyId)
      setDraftProperties(draftProperties.filter((p) => p.id !== propertyId))
      alert("Property published successfully!")
    } catch (error) {
      console.error("Error publishing property:", error)
      alert("Failed to publish property. Please try again.")
    } finally {
      setIsPublishing(false)
    }
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div className="space-y-0.5">
          <Label htmlFor="publish-status">Publish Status</Label>
          <p className="text-sm text-muted-foreground">Toggle to publish or unpublish the property listing</p>
        </div>
        <Switch id="publish-status" checked={property.status === "PUBLISHED"} onCheckedChange={handleStatusChange} />
      </div>
      <Button
        className="w-full"
        onClick={() => property.id && publishProperty(property.id)}
        disabled={isPublishing || property.status === "PUBLISHED"}
      >
        {isPublishing ? "Publishing..." : property.status === "PUBLISHED" ? "Update Listing" : "Publish Listing"}
      </Button>

      <div className="mt-8">
        <h3 className="text-lg font-semibold mb-4">Draft Properties</h3>
        {isLoading ? (
          <p>Loading draft properties...</p>
        ) : draftProperties.length === 0 ? (
          <p>No draft properties available.</p>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {draftProperties.map((draft) => (
              <Card key={draft.id}>
                <CardHeader>
                  <CardTitle>{draft.specifications.titleDeed || "Untitled Property"}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    {draft.location.address || "No address provided"}
                  </p>
                  <Button
                    className="w-full"
                    onClick={() => draft.id && publishProperty(draft.id)}
                    disabled={isPublishing}
                  >
                    Publish
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

