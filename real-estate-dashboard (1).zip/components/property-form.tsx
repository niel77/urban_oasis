"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { PropertyType } from "../types/property"
import { PropertyDetails } from "./property-details"
import { PropertyMedia } from "./property-media"
import { PropertyLocation } from "./property-location"
import { PropertyPublishing } from "./property-publishing"

export function PropertyForm() {
  const [property, setProperty] = useState<PropertyType>({
    type: "RESIDENTIAL",
    listingType: "RENT",
    specifications: {
      titleDeed: "",
      propertyType: "",
      size: "",
      bedrooms: 0,
      bathrooms: 0,
      parkingSpaces: 0,
      furnishingType: "",
      builtUpArea: "",
      totalPlotSize: "",
      layoutType: "",
    },
    pricing: {
      type: "YEAR",
      amount: "",
      currency: "AED",
    },
    location: {
      address: "",
      unitNo: "",
      coordinates: {
        latitude: 25.2048,
        longitude: 55.2708,
      },
    },
    media: {
      images: [],
      floorPlans: [],
      threeSixtyMedia: [],
      qrCode: "",
    },
    management: {
      reference: "",
      owner: "",
      availability: "AVAILABLE",
      availableFrom: new Date(),
    },
    propertyPermit: {
      type: "RERA",
      number: "",
    },
    status: "DRAFT",
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: "",
  })

  return (
    <div className="container mx-auto py-6">
      <Card>
        <Tabs defaultValue="details" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="details">Property Details</TabsTrigger>
            <TabsTrigger value="media">Media</TabsTrigger>
            <TabsTrigger value="location">Location</TabsTrigger>
            <TabsTrigger value="publishing">Publishing</TabsTrigger>
          </TabsList>
          <TabsContent value="details">
            <PropertyDetails property={property} setProperty={setProperty} />
          </TabsContent>
          <TabsContent value="media">
            <PropertyMedia property={property} setProperty={setProperty} />
          </TabsContent>
          <TabsContent value="location">
            <PropertyLocation property={property} setProperty={setProperty} />
          </TabsContent>
          <TabsContent value="publishing">
            <PropertyPublishing property={property} setProperty={setProperty} />
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  )
}

