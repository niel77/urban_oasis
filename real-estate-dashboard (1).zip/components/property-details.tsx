"use client"

import { useState } from "react"
import type { PropertyType } from "../types/property"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Home, Building2, Key, Banknote } from "lucide-react"
import { propertyService } from "../services/property-service"

interface PropertyDetailsProps {
  property: PropertyType
  setProperty: (property: PropertyType) => void
}

export function PropertyDetails({ property, setProperty }: PropertyDetailsProps) {
  const [isSaving, setIsSaving] = useState(false)

  const handleSpecificationChange = (key: string, value: string) => {
    setProperty({
      ...property,
      specifications: {
        ...property.specifications,
        [key]: value,
      },
    })
  }

  const handlePricingChange = (key: string, value: string) => {
    setProperty({
      ...property,
      pricing: {
        ...property.pricing,
        [key]: value,
        type: "YEAR",
        currency: "AED",
      },
    })
  }

  const handleManagementChange = (key: string, value: string) => {
    setProperty({
      ...property,
      management: {
        ...property.management,
        [key]: value,
      },
    })
  }

  const saveDraft = async () => {
    setIsSaving(true)
    try {
      const savedProperty = await propertyService.createProperty({
        ...property,
        status: "DRAFT",
      })
      setProperty(savedProperty)
      alert("Property saved as draft successfully!")
    } catch (error) {
      console.error("Error saving draft:", error)
      alert("Failed to save draft. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-6 p-6">
      <div className="grid gap-6">
        <div className="space-y-4">
          <Label>Property Type</Label>
          <div className="flex space-x-4">
            <Button
              variant={property.type === "RESIDENTIAL" ? "default" : "outline"}
              className="flex-1 h-20 flex flex-col items-center justify-center"
              onClick={() => setProperty({ ...property, type: "RESIDENTIAL" })}
            >
              <Home className="h-4 w-4 mb-2" />
              <span className="text-sm">Residential</span>
            </Button>
            <Button
              variant={property.type === "COMMERCIAL" ? "default" : "outline"}
              className="flex-1 h-20 flex flex-col items-center justify-center"
              onClick={() => setProperty({ ...property, type: "COMMERCIAL" })}
            >
              <Building2 className="h-4 w-4 mb-2" />
              <span className="text-sm">Commercial</span>
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <Label>Listing Type</Label>
          <div className="flex space-x-4">
            <Button
              variant={property.listingType === "RENT" ? "default" : "outline"}
              className="flex-1 h-20 flex flex-col items-center justify-center"
              onClick={() => setProperty({ ...property, listingType: "RENT" })}
            >
              <Key className="h-4 w-4 mb-2" />
              <span className="text-sm">For Rent</span>
            </Button>
            <Button
              variant={property.listingType === "SALE" ? "default" : "outline"}
              className="flex-1 h-20 flex flex-col items-center justify-center"
              onClick={() => setProperty({ ...property, listingType: "SALE" })}
            >
              <Banknote className="h-4 w-4 mb-2" />
              <span className="text-sm">For Sale</span>
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Specifications</h3>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="titleDeed">Title Deed</Label>
              <Input
                id="titleDeed"
                value={property.specifications.titleDeed}
                onChange={(e) => handleSpecificationChange("titleDeed", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="propertyType">Property Type</Label>
              <Select
                value={property.specifications.propertyType}
                onValueChange={(value) => handleSpecificationChange("propertyType", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select property type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="APARTMENT">Apartment</SelectItem>
                  <SelectItem value="VILLA">Villa</SelectItem>
                  <SelectItem value="TOWNHOUSE">Townhouse</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="size">Size (sqft)</Label>
              <Input
                id="size"
                type="text"
                value={property.specifications.size}
                onChange={(e) => handleSpecificationChange("size", e.target.value)}
                placeholder="Enter size"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bedrooms">No. of Bedrooms</Label>
              <Select
                value={property.specifications.bedrooms.toString()}
                onValueChange={(value) => handleSpecificationChange("bedrooms", Number.parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select number of bedrooms" />
                </SelectTrigger>
                <SelectContent>
                  {[0, 1, 2, 3, 4, 5, 6].map((num) => (
                    <SelectItem key={num} value={num.toString()}>
                      {num}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="bathrooms">No. of Bathrooms</Label>
              <Select
                value={property.specifications.bathrooms.toString()}
                onValueChange={(value) => handleSpecificationChange("bathrooms", Number.parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select number of bathrooms" />
                </SelectTrigger>
                <SelectContent>
                  {[1, 2, 3, 4, 5, 6].map((num) => (
                    <SelectItem key={num} value={num.toString()}>
                      {num}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="parkingSpaces">No. of Parking Spaces</Label>
              <Input
                id="parkingSpaces"
                type="number"
                value={property.specifications.parkingSpaces}
                onChange={(e) => handleSpecificationChange("parkingSpaces", Number.parseInt(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="furnishingType">Furnishing Type</Label>
              <Select
                value={property.specifications.furnishingType}
                onValueChange={(value) => handleSpecificationChange("furnishingType", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select furnishing type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="FURNISHED">Furnished</SelectItem>
                  <SelectItem value="UNFURNISHED">Unfurnished</SelectItem>
                  <SelectItem value="PARTIALLY_FURNISHED">Partially Furnished</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="builtUpArea">Built-up Area (sqft)</Label>
              <Input
                id="builtUpArea"
                type="text"
                value={property.specifications.builtUpArea}
                onChange={(e) => handleSpecificationChange("builtUpArea", e.target.value)}
                placeholder="Enter built-up area"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="totalPlotSize">Total Plot Size (sqft)</Label>
              <Input
                id="totalPlotSize"
                type="text"
                value={property.specifications.totalPlotSize}
                onChange={(e) => handleSpecificationChange("totalPlotSize", e.target.value)}
                placeholder="Enter total plot size"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="layoutType">Layout Type</Label>
              <Input
                id="layoutType"
                value={property.specifications.layoutType}
                onChange={(e) => handleSpecificationChange("layoutType", e.target.value)}
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <Label>Pricing (AED)</Label>
          <div className="space-y-2">
            <Label htmlFor="priceYear">Yearly Price (AED)</Label>
            <Input
              id="priceYear"
              type="text"
              value={property.pricing.amount}
              onChange={(e) => handlePricingChange("amount", e.target.value)}
              placeholder="Enter yearly price"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="cheques">Cheques</Label>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Select number of cheques" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 Cheque</SelectItem>
              <SelectItem value="2">2 Cheques</SelectItem>
              <SelectItem value="4">4 Cheques</SelectItem>
              <SelectItem value="6">6 Cheques</SelectItem>
              <SelectItem value="12">12 Cheques</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          <Label>Property Permit</Label>
          <div className="flex space-x-4">
            <Button
              variant={property.propertyPermit.type === "RERA" ? "default" : "outline"}
              className="flex-1 h-10"
              onClick={() =>
                setProperty({
                  ...property,
                  propertyPermit: { ...property.propertyPermit, type: "RERA" },
                })
              }
            >
              RERA
            </Button>
            <Button
              variant={property.propertyPermit.type === "DTCM" ? "default" : "outline"}
              className="flex-1 h-10"
              onClick={() =>
                setProperty({
                  ...property,
                  propertyPermit: { ...property.propertyPermit, type: "DTCM" },
                })
              }
            >
              DTCM
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <Label htmlFor="availability">Availability</Label>
          <Select
            value={property.management.availability}
            onValueChange={(value) => handleManagementChange("availability", value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select availability" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="AVAILABLE">Available</SelectItem>
              <SelectItem value="UNDER_OFFER">Under Offer</SelectItem>
              <SelectItem value="RESERVED">Reserved</SelectItem>
              <SelectItem value="RENTED">Rented</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex justify-end space-x-4">
          <Button onClick={saveDraft} disabled={isSaving}>
            {isSaving ? "Saving..." : "Save as Draft"}
          </Button>
          <Button>Next Step</Button>
        </div>
      </div>
    </div>
  )
}

